
from .template_store import TEMPLATES

def hardcoded_template_detect(text):
    for name, tpl in TEMPLATES.items():
        for kw in tpl.get("keywords", []):
            if kw.lower() in text.lower():
                return name, 0.95
    return None, 0.0

def embedding_template_detect(text):
    # placeholder for sentence-transformers similarity
    return None, 0.0
