
TEMPLATES = {
    "trade_confirmation_v1": {
        "keywords": ["TRADE CONFIRMATION"],
        "aliases": {
            "trade_id": ["trade id","transaction reference"],
            "counterparty": ["counterparty","cpty"],
            "amount": ["amount","notional"]
        }
    }
}
