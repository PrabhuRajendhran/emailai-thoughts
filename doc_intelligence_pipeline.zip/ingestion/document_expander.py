
import os

SUPPORTED_EXT = {".pdf",".docx",".xlsx",".msg",".jpg",".jpeg",".png",".txt",".md"}

def expand_inputs(files, depth=0, max_depth=2):
    expanded = []
    for f in files:
        if not os.path.exists(f):
            continue
        ext = os.path.splitext(f)[1].lower()
        if ext in SUPPORTED_EXT:
            expanded.append({"path": f, "type": ext})
    return expanded
