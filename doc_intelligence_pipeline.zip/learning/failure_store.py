
import os, json

def store_failure(config, doc_id, payload):
    os.makedirs(config["failure_store"], exist_ok=True)
    path = os.path.join(config["failure_store"], f"{doc_id}.json")
    with open(path,"w") as f:
        json.dump(payload,f,indent=2)
