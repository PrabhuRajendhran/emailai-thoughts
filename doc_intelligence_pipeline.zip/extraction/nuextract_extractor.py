
def extract(text):
    return {
        "fields": {
            "trade_id": {"value": "TRX123", "confidence": 0.85}
        },
        "source": "nuextract"
    }
