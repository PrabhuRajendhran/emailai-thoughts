
def parse(text, template=None):
    return {
        "fields": {
            "counterparty": {"value": "JP Morgan", "confidence": 0.9}
        },
        "source": "deterministic"
    }
