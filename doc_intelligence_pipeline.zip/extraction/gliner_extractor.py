
def extract(text):
    return {
        "fields": {
            "currency": {"value": "USD", "confidence": 0.8}
        },
        "source": "gliner"
    }
