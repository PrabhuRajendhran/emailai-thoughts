
def extract(text):
    return {
        "fields": {
            "amount": {"value": "2000000", "confidence": 0.9}
        },
        "source": "numarkdown"
    }
