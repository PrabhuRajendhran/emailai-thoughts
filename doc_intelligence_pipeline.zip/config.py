
CONFIG = {
    # ingestion
    "ingestion_mode": "batch",  # batch | kafka
    "input_directory": "./input_docs",
    "max_recursion_depth": 2,

    # execution
    "execution_mode": "single",  # single | ray

    # OCR
    "ocr_engine": "paddle",  # paddle | numarkdown | hybrid

    # feature toggles
    "enable_layout_graph": True,
    "enable_table_reconstruction": True,
    "enable_template_retrieval": True,
    "enable_hardcoded_templates": True,
    "enable_embedding_templates": True,
    "enable_gliner": True,
    "enable_numarkdown_extraction": True,
    "enable_nuextract": True,

    # template retrieval
    "template_similarity_threshold": 0.85,

    # directories
    "model_dir": "/research/models",
    "failure_store": "./failure_store"
}
