
from ocr.ocr_router import run_ocr
from layout.layout_graph import build_layout_graph
from layout.table_reconstruction import reconstruct_tables
from templates.template_retriever import hardcoded_template_detect
from extraction.deterministic_parser import parse
from extraction.gliner_extractor import extract as gliner_extract
from extraction.numarkdown_extractor import extract as nm_extract
from extraction.nuextract_extractor import extract as ne_extract
from consensus.consensus_engine import combine

def process_document(doc, config):
    ocr = run_ocr(doc["path"], config)
    text = ocr["text"]

    template, _ = hardcoded_template_detect(text)

    results = []
    results.append(parse(text, template))

    if config["enable_gliner"]:
        results.append(gliner_extract(text))

    if config["enable_numarkdown_extraction"]:
        results.append(nm_extract(text))

    if config["enable_nuextract"]:
        results.append(ne_extract(text))

    final = combine(results)

    return final
