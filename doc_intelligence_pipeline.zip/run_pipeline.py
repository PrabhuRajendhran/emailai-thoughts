
import json
from config import CONFIG
from ingestion.batch_processor import list_files
from ingestion.document_expander import expand_inputs
from pipeline.extraction_pipeline import process_document

def run_batch():
    files = list_files(CONFIG["input_directory"])
    docs = expand_inputs(files, max_depth=CONFIG["max_recursion_depth"])

    outputs = []
    for d in docs:
        result = process_document(d, CONFIG)
        outputs.append({"doc": d["path"], "result": result})

    print(json.dumps(outputs, indent=2))

if __name__ == "__main__":
    if CONFIG["ingestion_mode"] == "batch":
        run_batch()
    else:
        print("Kafka mode not implemented in this minimal runnable version.")
