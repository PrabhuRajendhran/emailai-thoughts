
def combine(results):
    combined = {}
    for r in results:
        for k,v in r["fields"].items():
            if k not in combined or combined[k]["confidence"] < v["confidence"]:
                combined[k] = v
    return combined
