
def run_numarkdown_ocr(doc_path):
    # placeholder stub for nuMarkdown OCR
    return {
        "text": f"nuMarkdown OCR text from {doc_path}",
        "confidence": 0.96,
        "blocks": []
    }
