
from .paddle_ocr import run_paddle_ocr
from .numarkdown_ocr import run_numarkdown_ocr

def run_ocr(doc_path, config):
    engine = config["ocr_engine"]
    if engine == "paddle":
        return run_paddle_ocr(doc_path)
    elif engine == "numarkdown":
        return run_numarkdown_ocr(doc_path)
    elif engine == "hybrid":
        result = run_paddle_ocr(doc_path)
        if result.get("confidence",1) < 0.8:
            return run_numarkdown_ocr(doc_path)
        return result
    else:
        raise ValueError("Unknown OCR engine")
