
def run_paddle_ocr(doc_path):
    # placeholder stub for PaddleOCR integration
    return {
        "text": f"OCR text from {doc_path}",
        "confidence": 0.95,
        "blocks": []
    }
