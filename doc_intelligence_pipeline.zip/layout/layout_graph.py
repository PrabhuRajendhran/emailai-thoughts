
def build_layout_graph(ocr_output):
    # placeholder spatial graph
    return {"nodes": [], "edges": []}
