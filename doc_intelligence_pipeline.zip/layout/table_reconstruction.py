
def reconstruct_tables(ocr_output):
    # placeholder table detection
    return []
