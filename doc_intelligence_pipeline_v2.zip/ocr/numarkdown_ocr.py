
def run(doc):
    return {
        "text": f"nuMarkdown OCR text from {doc}",
        "confidence": 0.96,
        "blocks": []
    }
