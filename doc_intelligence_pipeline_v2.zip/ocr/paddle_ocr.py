
def run(doc):
    return {
        "text": f"PaddleOCR text from {doc}",
        "confidence": 0.93,
        "blocks": []
    }
