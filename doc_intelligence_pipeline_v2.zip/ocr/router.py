
from .paddle_ocr import run as paddle
from .numarkdown_ocr import run as nm

def run_ocr(doc, config):
    if config["ocr_engine"] == "paddle":
        return paddle(doc)

    if config["ocr_engine"] == "numarkdown":
        return nm(doc)

    if config["ocr_engine"] == "hybrid":
        res = paddle(doc)
        if res["confidence"] < 0.9:
            return nm(doc)
        return res
