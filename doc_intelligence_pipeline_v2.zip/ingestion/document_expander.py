
import os

SUPPORTED_EXT = {".pdf",".docx",".xlsx",".msg",".jpg",".jpeg",".png",".txt",".md"}

def expand_inputs(files):
    docs = []
    for f in files:
        ext = os.path.splitext(f)[1].lower()
        if ext in SUPPORTED_EXT:
            docs.append({"path": f, "type": ext})
    return docs
