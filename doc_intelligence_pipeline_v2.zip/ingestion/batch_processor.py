
import os

def list_files(input_dir):
    files = []
    for root, _, filenames in os.walk(input_dir):
        for f in filenames:
            files.append(os.path.join(root, f))
    return files
