
from confluent_kafka import Consumer

def start_kafka_consumer(config):
    conf = {
        'bootstrap.servers': 'localhost:9092',
        'group.id': 'doc-pipeline',
        'auto.offset.reset': 'earliest'
    }
    consumer = Consumer(conf)
    consumer.subscribe(['documents'])
    return consumer
