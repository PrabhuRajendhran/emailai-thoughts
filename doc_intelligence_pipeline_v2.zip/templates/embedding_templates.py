
def detect(text):
    # placeholder for sentence-transformer similarity
    return None, 0.0
