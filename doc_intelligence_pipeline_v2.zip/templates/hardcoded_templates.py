
TEMPLATES = {
 "trade_confirmation": {
  "keywords": ["trade confirmation","transaction confirmation"]
 }
}
