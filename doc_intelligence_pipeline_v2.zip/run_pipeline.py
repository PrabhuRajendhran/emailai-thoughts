
import json
from config import CONFIG
from ingestion.batch_processor import list_files
from ingestion.document_expander import expand_inputs
from pipeline.engine import process_document
from distributed.ray_executor import run_parallel

def run_batch():
    files = list_files(CONFIG["input_directory"])
    docs = expand_inputs(files)

    if CONFIG["execution_mode"] == "ray":
        results = run_parallel(docs, CONFIG)
    else:
        results = [process_document(d, CONFIG) for d in docs]

    print(json.dumps(results, indent=2))

if __name__ == "__main__":
    run_batch()
