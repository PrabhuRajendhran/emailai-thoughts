
import ray
from pipeline.engine import process_document

def run_parallel(docs, config):
    ray.init(ignore_reinit_error=True)

    @ray.remote
    def worker(doc):
        return process_document(doc, config)

    futures = [worker.remote(d) for d in docs]
    results = ray.get(futures)

    ray.shutdown()
    return results
