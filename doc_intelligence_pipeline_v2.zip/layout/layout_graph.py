
def build_graph(ocr):
    return {"nodes": [], "edges": []}
