
def reconstruct(ocr):
    return []
