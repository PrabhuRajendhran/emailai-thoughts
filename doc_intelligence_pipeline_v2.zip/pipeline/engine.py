
from ocr.router import run_ocr
from extraction.deterministic import extract as det
from extraction.gliner_extractor import extract as gliner
from extraction.numarkdown_extractor import extract as nm
from extraction.nuextract_extractor import extract as ne
from consensus.engine import merge

def process_document(doc, config):
    ocr = run_ocr(doc["path"], config)
    text = ocr["text"]

    results = []
    results.append(det(text))

    if config["enable_gliner"]:
        results.append(gliner(text))

    if config["enable_numarkdown_extraction"]:
        results.append(nm(text))

    if config["enable_nuextract"]:
        results.append(ne(text))

    return merge(results)
