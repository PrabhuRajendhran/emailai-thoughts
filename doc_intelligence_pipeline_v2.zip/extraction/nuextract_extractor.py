
def extract(text):
    return {
        "fields": {
            "trade_id": {"value": "TRX999", "confidence": 0.88}
        },
        "source": "nuextract"
    }
