
def extract(text):
    return {
        "fields": {
            "currency": {"value": "USD", "confidence": 0.85}
        },
        "source": "gliner"
    }
