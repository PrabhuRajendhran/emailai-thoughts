
def extract(text):
    return {
        "fields": {
            "counterparty": {"value": "Goldman Sachs", "confidence": 0.9}
        },
        "source": "deterministic"
    }
