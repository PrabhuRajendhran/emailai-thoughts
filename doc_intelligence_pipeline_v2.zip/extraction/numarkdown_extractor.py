
def extract(text):
    return {
        "fields": {
            "amount": {"value": "5000000", "confidence": 0.91}
        },
        "source": "numarkdown"
    }
