
def merge(results):
    merged = {}
    for r in results:
        for k,v in r["fields"].items():
            if k not in merged or merged[k]["confidence"] < v["confidence"]:
                merged[k] = v
    return merged
