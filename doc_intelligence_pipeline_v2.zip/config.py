
CONFIG = {
    # ingestion
    "ingestion_mode": "batch",  # batch | kafka
    "input_directory": "./input_docs",
    "max_recursion_depth": 2,

    # execution
    "execution_mode": "single",  # single | ray
    "num_workers": 4,

    # OCR
    "ocr_engine": "hybrid",  # paddle | numarkdown | hybrid

    # model paths
    "model_dir": "/research/models",
    "embedding_model": "/research/models/sentence-transformer",

    # feature toggles
    "enable_layout_graph": True,
    "enable_table_reconstruction": True,
    "enable_template_retrieval": True,
    "enable_gliner": True,
    "enable_numarkdown_extraction": True,
    "enable_nuextract": True,

    # output
    "failure_store": "./failure_store"
}
